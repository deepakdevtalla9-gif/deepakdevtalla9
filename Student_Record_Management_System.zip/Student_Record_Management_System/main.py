import csv
import json
import os

CSV_FILE = "students.csv"
JSON_FILE = "students.json"


def load_students():
    """Load records from JSON if available, otherwise CSV."""
    if os.path.exists(JSON_FILE):
        try:
            with open(JSON_FILE, "r", encoding="utf-8") as file:
                data = json.load(file)
                return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            print("Could not read JSON data. Starting with an empty list.")
            return []

    if os.path.exists(CSV_FILE):
        try:
            with open(CSV_FILE, "r", newline="", encoding="utf-8") as file:
                return list(csv.DictReader(file))
        except OSError:
            print("Could not read CSV data. Starting with an empty list.")
    return []


def save_students(students):
    """Save records to both CSV and JSON files."""
    fields = ["id", "name", "course", "email"]
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(students)

    with open(JSON_FILE, "w", encoding="utf-8") as file:
        json.dump(students, file, indent=4)


def add_student(students):
    student_id = input("Enter student ID: ").strip()
    if any(student["id"] == student_id for student in students):
        print("That student ID already exists.")
        return

    name = input("Enter student name: ").strip()
    course = input("Enter course: ").strip()
    email = input("Enter email: ").strip()

    if not student_id or not name:
        print("Student ID and name are required.")
        return

    students.append({
        "id": student_id,
        "name": name,
        "course": course,
        "email": email
    })
    save_students(students)
    print("Student added successfully.")


def view_students(students):
    if not students:
        print("No student records found.")
        return

    print("\n--- Student Records ---")
    for student in students:
        print(
            f"ID: {student.get('id', '')} | "
            f"Name: {student.get('name', '')} | "
            f"Course: {student.get('course', '')} | "
            f"Email: {student.get('email', '')}"
        )


def update_student(students):
    student_id = input("Enter the ID to update: ").strip()
    for student in students:
        if student.get("id") == student_id:
            name = input(f"New name [{student.get('name', '')}]: ").strip()
            course = input(f"New course [{student.get('course', '')}]: ").strip()
            email = input(f"New email [{student.get('email', '')}]: ").strip()

            if name:
                student["name"] = name
            if course:
                student["course"] = course
            if email:
                student["email"] = email

            save_students(students)
            print("Student updated successfully.")
            return

    print("Student ID not found.")


def delete_student(students):
    student_id = input("Enter the ID to delete: ").strip()
    for student in students:
        if student.get("id") == student_id:
            students.remove(student)
            save_students(students)
            print("Student deleted successfully.")
            return
    print("Student ID not found.")


def search_student(students):
    query = input("Enter a student ID or name to search: ").strip().lower()
    matches = [
        student for student in students
        if query == student.get("id", "").lower()
        or query in student.get("name", "").lower()
    ]
    if matches:
        view_students(matches)
    else:
        print("No matching student found.")


def main():
    students = load_students()

    while True:
        print("\n===== Student Record Management System =====")
        print("1. Add student")
        print("2. View all students")
        print("3. Update student")
        print("4. Delete student")
        print("5. Search student")
        print("6. Exit")

        try:
            choice = int(input("Choose an option (1-6): "))
        except ValueError:
            print("Please enter a number from 1 to 6.")
            continue

        if choice == 1:
            add_student(students)
        elif choice == 2:
            view_students(students)
        elif choice == 3:
            update_student(students)
        elif choice == 4:
            delete_student(students)
        elif choice == 5:
            search_student(students)
        elif choice == 6:
            print("Thank you for using the program!")
            break
        else:
            print("Invalid choice. Please select 1 to 6.")


if __name__ == "__main__":
    main()
