# Module 02 practice: functions, lambda, list comprehension, exceptions

def calculate_total(price, quantity=1):
    """Return total price for the given quantity."""
    return price * quantity


square = lambda number: number ** 2

numbers = [1, 2, 3, 4, 5, 6]
squares = [square(number) for number in numbers]
evens = [number for number in numbers if number % 2 == 0]

print("Total:", calculate_total(100, 3))
print("Squares:", squares)
print("Even numbers:", evens)

try:
    value = int(input("Enter a whole number: "))
    print("You entered:", value)
except ValueError:
    print("Invalid input. Please enter a whole number.")
finally:
    print("Practice program finished.")
