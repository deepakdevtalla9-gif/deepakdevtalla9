# Student Record Management System

A beginner-friendly Python project for Module 02: Functions, Files & Exception Handling.

## Features
- Add, view, update, delete, and search student records
- Save records in both CSV and JSON formats
- Handle invalid menu input with `try-except`
- Uses functions, parameters, return values, list comprehensions, and file handling

## Requirements
- Python 3.9 or newer
- No external packages required

## Run the project
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

```bash
python main.py
```

To practise the module topics separately, run:

```bash
python practice_topics.py
```

## Files created by the app
- `students.csv`
- `students.json`

These files are generated when you add or update student records.

## Notes
This is a learning project. Use sample data only; do not store sensitive personal information.
